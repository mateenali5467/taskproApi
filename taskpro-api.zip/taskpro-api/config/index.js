module.exports = {
  AWS_ACCESS_KEY: '',
  AWS_SECRET_KEY: '',
  AWS_REGION: '',
  BUCKET: '', // aws bucket
  ONESIGNAL_APP: '', // app id
  ONESIGNAL_KEY: ''
};



